# turmaN-3tri
Quinta-feira - 9h às 10h e 40 min
